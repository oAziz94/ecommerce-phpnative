<?php

interface operation {
    function updateData();
    function deleteData();
    function insertData();
    function getAllData();
}

?>